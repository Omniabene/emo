

from keras.models import model_from_json
import matplotlib.pyplot as plt
from keras.preprocessing.image import ImageDataGenerator
from sklearn.metrics import confusion_matrix, classification_report,ConfusionMatrixDisplay

emotion_dict = {0: "Angry", 1: "Disgusted", 2: "Fearful", 3: "Happy", 4: "Neutral", 5: "Sad", 6: "Surprised"}

json_file = open('model/emotion_model.json', 'r')
loaded_model_json = json_file.read()
json_file.close()
emotion_model = model_from_json(loaded_model_json)


emotion_model.load_weights("model/emotion_model.h5")
print("Loaded model from disk")


test_data_gen = ImageDataGenerator(rescale=1./255)

img_shape = 224
test_data = test_data_gen.flow_from_directory(
    'data/test2',
    class_mode="categorical",
    target_size=(img_shape,img_shape),
    color_mode="rgb",
    shuffle=False,
    batch_size=64,
)

predictions = emotion_model.predict(test_data)

print("-----------------------------------------------------------------")

c_matrix = confusion_matrix(test_data.classes, predictions.argmax(axis=1))
print(c_matrix)
cm_display = ConfusionMatrixDisplay(confusion_matrix=c_matrix, display_labels=emotion_dict)
cm_display.plot(cmap=plt.cm.Blues)
plt.show()

print("-----------------------------------------------------------------")
print(classification_report(test_data.classes, predictions.argmax(axis=1)))





