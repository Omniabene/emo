import tensorflow as tf
from keras.callbacks import ModelCheckpoint, EarlyStopping
from keras.layers import Dense, Flatten, Dropout, BatchNormalization
from keras.models import Sequential
from keras.preprocessing.image import ImageDataGenerator

img_shape = 224
batch_size = 64
train_data_path = 'data/train'
test_data_path = 'data/test'

# Генераторы для обработки тестовых и тренировочных изображений
train_preprocessor = ImageDataGenerator(
    rescale=1 / 255.,
    rotation_range=10,
    zoom_range=0.2,
    width_shift_range=0.1,
    height_shift_range=0.1,
    horizontal_flip=True,
    fill_mode='nearest',
)

test_preprocessor = ImageDataGenerator(
    rescale=1 / 255.,
)
#
train_data = train_preprocessor.flow_from_directory(
    train_data_path,
    class_mode="categorical",
    target_size=(img_shape, img_shape),
    color_mode='rgb',
    shuffle=True,
    batch_size=batch_size,
    subset='training',
)

test_data = test_preprocessor.flow_from_directory(
    test_data_path,
    class_mode="categorical",
    target_size=(img_shape, img_shape),
    color_mode="rgb",
    shuffle=False,
    batch_size=batch_size,
)
# Создаем модель, используя предварительно обученные веса ResNet50V2
ResNet50V2 = tf.keras.applications.ResNet50V2(input_shape=(224, 224, 3),
                                              include_top=False,
                                              weights='imagenet'
                                              )
# Разблокируем слои для обучения
ResNet50V2.trainable = True

# Замораживаем все слои кроме последих 50
for layer in ResNet50V2.layers[:-50]:
    layer.trainable = False

# Создаем модель
def Create_ResNet50V2_Model():
    model = Sequential([
        ResNet50V2,
        # Слой регуляризации (отключаем 25 процентов нейронов в слое)
        Dropout(.25),
        # Слой нормализации
        BatchNormalization(),
        # Слой сглаживания
        Flatten(),
        # Полносвязный слой
        Dense(64, activation='relu'),
        BatchNormalization(),
        # слой регуляризации
        Dropout(.5),
        Dense(7, activation='softmax')
    ])
    return model

# создаем модель
ResNet50V2_Model = Create_ResNet50V2_Model()
# Выводи информацию о модели
ResNet50V2_Model.summary()
# Компилируем модель с анализатором и функцией потерь и метрикой точностью
ResNet50V2_Model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])


# колбек который останавливает обучение если модель перестает улучшаться
Early_Stopping = EarlyStopping(monitor='val_accuracy', patience=7, restore_best_weights=True, verbose=1)
# уменьшается скорость если функция потерь не улучшается
Reducing_LR = tf.keras.callbacks.ReduceLROnPlateau(monitor='val_loss',
                                                   factor=0.2,
                                                   patience=2,
                                                   verbose=1)

callbacks = [Early_Stopping, Reducing_LR]
# количество шагов
steps_per_epoch = train_data.n // train_data.batch_size
validation_steps = test_data.n // test_data.batch_size
# запускаем процесс обучения
ResNet50V2_history = ResNet50V2_Model.fit(train_data,
                                          validation_data=test_data,
                                          epochs=15,
                                          batch_size=batch_size,
                                          callbacks=callbacks,
                                          steps_per_epoch=steps_per_epoch,
                                          validation_steps=validation_steps)

model_json = ResNet50V2_Model.to_json()
with open("emotion_model.json", "w") as json_file:
    json_file.write(model_json)

ResNet50V2_Model.save_weights('emotion_model.h5')
